# 접근성 분석 방법론 참고 자료

> 이 문서는 다음 논문을 주요 이론적 기반으로 삼는다:
> **Ahn, J., Kim, H., & Lee, T. (2026). A Conceptual Framework for Spatial Accessibility: Aligning Metrics with Urban Service Determinants. KAIST ISysE Preprint.**

---

## 목차

1. [핵심 개념: 공간 접근성의 3요소](#1-핵심-개념-공간-접근성의-3요소)
2. [서비스 유형 분류 (3 Archetypes)](#2-서비스-유형-분류-3-archetypes)
3. [지표 패밀리별 수식 및 해석](#3-지표-패밀리별-수식-및-해석)
   - 3.1 Proximity-based Measures
   - 3.2 Opportunity-based Measures (COM, Gravity)
   - 3.3 Provider-to-Population Ratio (PPR)
   - 3.4 Competition-adjusted Measures (2SFCA, E2SFCA)
4. [서비스-지표 정렬 가이드](#4-서비스-지표-정렬-가이드)
5. [Catchment 반경 설정 근거](#5-catchment-반경threshold_km-설정-근거)
6. [거리 감쇠 함수 선택 가이드 (E2SFCA용)](#6-거리-감쇠-함수-선택-가이드-e2sfca용)
7. [방법론적 주의사항](#7-방법론적-주의사항)

---

## 1. 핵심 개념: 공간 접근성의 3요소

Ahn et al. (2026)은 공간 접근성을 세 가지 개념적 구성요소로 분해한다. 기존 연구들이 알고리즘적 정교함에 집중하는 경향이 있었던 반면, 이 프레임워크는 **"fitness for purpose"** — 분석 목적에 맞는 지표 선택 — 을 강조한다.

기존 문헌에서 접근성의 조작적 정의는 분절되어 있었다. 일부 연구는 접근성을 가장 가까운 시설까지의 물리적 근접성으로 정의하고, 다른 연구는 도달 가능한 기회의 양으로, 또 다른 연구는 제한된 서비스 용량을 두고 경쟁이 발생할 때의 공급-수요 균형으로 해석한다 (Geurs & van Wee, 2004; Neutens, 2015). 명확한 원칙 없이 지표를 선택하면, "낮은 접근성"이 도달 어려움을 반영하는지, 기회 부족을 반영하는지, 공급-수요 불균형을 반영하는지 해석하기 어려워진다.

### 1.1 Travel Impedance (이동 저항 / 도달가능성)
- 출발지(거주지)에서 목적지(시설)까지의 이동에 대한 저항
- 이동 시간 또는 거리로 표현 (주로 네트워크 기반)
- 정책적 의미: **낮은 impedance = 더 빠른/쉬운 접근**
- 응급 상황처럼 신속한 도달 자체가 성과 지표인 경우 가장 중요한 요소

### 1.2 Reachable Opportunities (도달 가능한 기회의 양)
- 실현 가능한 이동 범위 내에서 접근할 수 있는 서비스 기회의 양 (및 질, 용량)
- 지표 예: 반경 내 시설 수, 누적 용량, 거리 가중 기회 합계
- 정책적 의미: **얼마나 많은 선택지가 이동 가능 범위 내에 있는가**

### 1.3 Competition (경쟁 / 공급-수요 상호작용)
- 제한된 서비스 용량을 여러 이용자가 공유할 때 발생하는 경쟁
- 시설이 가까이 있어도 수요 과잉이면 **실질 접근성은 낮을 수 있음**
- Impedance 및 Opportunity와 개념적으로 구별되는 독립 요소
- 정책적 의미: **공급-수요 균형이 실질적 접근가능성을 결정**

> 💡 **핵심 인사이트** (Ahn et al., 2026): 지표 선택은 단순한 기술적 결정이 아니라, 정책 맥락에서 "낮은 접근성"이 무엇을 의미하는지를 규정하는 **개념적 결정**이다. 동일한 수치적 정의의 "접근성"이라도 서비스에 따라 그 의미가 다를 수 있다.

---

## 2. 서비스 유형 분류 (3 Archetypes)

Ahn et al. (2026)은 **지배적 결정요인(dominant determinant)** 개념을 도입한다. 세 가지 접근성 요소 중 어느 것이 해당 서비스의 정책적 관련성을 주로 결정하는가를 기준으로 도시 서비스를 세 가지 유형으로 분류한다.

이 분류는 나머지 요소들이 무관하다는 의미가 아니라, 정책적으로 "낮은 접근성"을 어떻게 해석해야 하는지와 어떤 지표 패밀리가 가장 타당한지를 전경화하는 실용적 방법이다.

```
              Impedance
                  ▲
                  │  Time-critical
                  │  services
                  │
  Opportunity ◄───┼───► Competition
                  │
    Opportunity-      Capacity-
    driven            constrained
    services          services
```

### Type I: Time-critical (임피던스 지배형)
| 항목 | 내용 |
|------|------|
| **정책 목표** | 가장 가까운 적절한 시설로의 신속한 도달 |
| **성과 기준** | 임계 시간 내 도착 여부 (골든타임) |
| **해당 시설** | 응급실, 소방서, 재난 대피소, 외상센터, 분만응급 |
| **추천 지표** | MIN, 반응시간 커버리지 |
| **주의** | 2SFCA 계열 사용 불필요 — 불필요한 파라미터 추가, 정책 인사이트 없음 |

이 유형에서는 이동 임피던스(분)의 미미한 차이도 성과와 직결된다. 가장 가까운 시설 너머의 추가 기회는 통상적 평가에서 제한적인 정책 가치만 갖는다.

### Type II: Opportunity-driven (기회 지배형)
| 항목 | 내용 |
|------|------|
| **정책 목표** | 이동 가능 범위 내 서비스 기회의 양 |
| **성과 기준** | 얼마나 많은 선택지가 접근 가능한가 |
| **해당 시설** | 공원, 식료품점, 문화시설, 대형마트, 약국 |
| **추천 지표** | COM (누적 기회 지표), Gravity-based measures |
| **주의** | 최근접 지표만 사용하면 선택지 다양성을 포착 못함 |

### Type III: Capacity-constrained (경쟁 지배형)
| 항목 | 내용 |
|------|------|
| **정책 목표** | 제한된 공급 용량 대비 수요 경쟁의 형평성 |
| **성과 기준** | 공급이 인근 수요를 충족하는가 |
| **해당 시설** | 1차 의료(내과·가정의학), 소아과, **정신건강의학과**, 산부인과, 학교, 어린이집 |
| **추천 지표** | 2SFCA, E2SFCA |
| **주의** | Proximity만 사용하면 수요 경쟁으로 인한 실질 접근성 부족을 **과소평가** |

시설이 가까이 있더라도 용량이 포화 상태라면 실질적인 접근을 보장하지 못한다. 따라서 공간적 catchment 내 공급-수요 균형을 명시적으로 표현하는 지표가 필요하다.

> ⚠️ **혼합형(Hybrid) 사례** (Ahn et al., 2026): 많은 실제 서비스는 복합적 특성을 보인다. 예를 들어 의료는 응급으로 프레이밍하면 Type I이지만, 정기 1차 진료로 프레이밍하면 Type III다. 유형 분류는 특정 정책 맥락에서의 **서비스 목적과 평가 프레임**에 따라 결정된다.

---

## 3. 지표 패밀리별 수식 및 해석

### 3.1 Proximity-based Measures (근접성 지표)

**최근접 임피던스 (MIN)**
```
A_i^min = min_{j∈S} d_ij
```
- S: 전체 공급 시설 집합
- 출력 해석: "가장 가까운 시설까지의 거리/시간" (값이 작을수록 접근성 좋음)

**k-최근접 평균 (k-avg)** (Apparicio et al., 2008)
```
A_i^{k-avg} = (1/k) Σ_{m=1}^{k} d_i(m)
```
- d_i(m): i에서 m번째로 가까운 시설까지의 임피던스
- 활용: 가장 가까운 시설이 이용 불가일 때의 대안(fallback) 고려 시

**구현 시 필요 데이터**:
- 수요 위치 i, 공급 위치 j, 임피던스 d_ij
- 핵심 선택: 임피던스 정의 (시간 vs. 거리; 네트워크 vs. 유클리드), 선택적 k

**장점**: 계산 단순, 해석 명확 ("가장 가까운 응급실까지 10분"), 서비스 공백 지점 파악 효과적
**한계**: 기회의 양이나 수요 경쟁을 반영하지 않음 — 비응급 서비스에서는 정보량 부족

---

### 3.2 Opportunity-based Measures (기회 기반 지표)

#### 3.2.1 누적 기회 지표 (COM) (Wachs & Kumagai, 1973)
```
A_i^COM = Σ_{j∈S} S_j · I(d_ij ≤ d₀)
```
- S_j: 공급량 (시설 수 카운트 시 S_j = 1)
- I(·): d₀ 이내이면 1, 아니면 0인 지시 함수
- d₀: Catchment 반경 (threshold_km)
- 출력 해석: "d₀ 이내에 접근 가능한 기회의 총량"

COM은 실현 가능한 범위 내 모든 기회가 동등하게 접근 가능하다고 가정한다. 정책적 의미는 catchment 내 이동 비용의 세밀한 차이보다 **도달 가능한 기회의 양**에 결부된다.

**장점**: 정책 친화적, 공간적 불균형 파악 용이
**한계**: d₀ 선택에 민감, 경계면 절벽 효과(cliff-edge) — 반경 바로 밖 기회는 0으로 처리, 수요 경쟁 미반영

#### 3.2.2 중력 모형 (Gravity-based) (Hansen, 1959)
```
A_i^Grav = Σ_{j∈S} S_j · f(d_ij)
```
- f(d_ij): 단조 감소 함수 (예: d_ij^{-β} 또는 exp(-β·d_ij))
- β: 감쇠 속도 조절 파라미터

더 크거나 매력적인 기회에 도달하기 위해 더 먼 거리를 이동하려는 의향과 이동 임피던스 간의 연속적 트레이드오프를 표현한다.

**장점**: 연속적 감쇠로 절벽 효과 완화, 공간적 연속성 반영
**한계**: 감쇠 함수·파라미터 선택에 민감, 수요 경쟁 미반영 — 용량 제약 서비스에서는 한계

---

### 3.3 Provider-to-Population Ratio (PPR): 비공간 기준선 지표

**Provider-to-Population Ratio (PPR)**는 총 공급량을 인구로 나눠 서비스 공급 적정성을 요약하는 단순 기준선 지표다 (Guagliardo, 2004). Ahn et al. (2026)은 이 지표가 Figure 1(b)의 **기회(Opportunity)–경쟁(Competition) 경계**에 위치한다고 설명한다. PPR은 인구 정규화를 통해 수요 압력을 반영하지만, 이동 임피던스나 공간적 catchment 상호작용은 표현하지 않아 **비공간 기준선**으로 분류된다.

**논문 정의 (Ahn et al., 2026, Eq. 5) — 공간 단위 기반:**
```
PPR_g = S_g / P_g
```
- S_g: 공간 단위 g의 총 공급량 (의료인 수, 시설 수 등)
- P_g: 공간 단위 g의 인구
- 출력 해석: "인구 1인당 공급량" (값이 **클수록** 접근성 좋음)

**이 MCP의 구현 — Catchment 기반 확장:**

이 도구는 논문의 행정 단위 기반 PPR을 공간적으로 확장하여, 수요지점 i로부터 **threshold_km 반경 내 공급량**을 합산한 뒤 인구로 나누는 방식을 사용한다. 이를 통해 행정 경계를 넘는 공급 접근성을 반영할 수 있다.

| `ratio_type` 파라미터 | 수식 | 해석 | 방향 |
|---|---|---|---|
| `supply_per_population` *(논문 정의와 동일)* | Σ(S_j : d_ij ≤ d₀) / P_i | 인구 1인당 공급 (클수록 좋음) | higher_is_better |
| `population_per_supply` *(기본값)* | P_i / Σ(S_j : d_ij ≤ d₀) | 공급 1단위당 경쟁 인구 (작을수록 좋음) | lower_is_better |

**구현 시 필요 파라미터**:
- `threshold_km`: 공급 집계 반경
- `ratio_type`: `"supply_per_population"` 또는 `"population_per_supply"` (기본값)

**장점**: 계산 단순, 정책 커뮤니케이션 용이, 다른 지표 결과의 기준선(baseline) 비교에 유용

**한계**: 공급지점 주변의 경쟁 수요를 반영하지 않음 (2SFCA의 R_j 계산 없음) — 인구 밀집 지역에서 실질 접근성을 과대평가할 수 있음; 행정 경계를 자유롭게 이용하는 현실 행동 패턴을 단순화

> ⚠️ **2SFCA와의 핵심 차이**: 2SFCA는 각 공급지점 j의 catchment 내 경쟁 수요를 반영한 공급-수요 비율 R_j를 먼저 계산한 뒤 집계한다. 반면 PPR은 수요지점 i 기준 반경 내 공급을 단순 합산하여 인구로 나눈다. 따라서 PPR은 경쟁 효과를 반영하지 못한다. 의료 접근성의 형평성 진단에는 2SFCA 또는 E2SFCA가 권장된다.

---

### 3.4 Competition-adjusted Measures (경쟁 조정 지표)

FCA(Floating Catchment Area) 프레임워크는 공간적 catchment 내 공급 용량과 주변 수요를 결합하여 경쟁을 조작화한다. 근접성이나 기회 수와 달리, FCA는 수요를 계산에 내장함으로써 경쟁 요소를 조작화한다.

**2SFCA (Two-Step Floating Catchment Area)** (Luo & Wang, 2003)

Step 1: 각 공급지점 j의 공급-수요 비율 계산
```
R_j = S_j / Σ_{k: d_kj ≤ d₀} P_k
```
- S_j: 공급 용량 (의사 수, 시설 수 등)
- P_k: 수요 인구
- 해석: j 시설 주변 경쟁 수요 단위당 가용 공급량

Step 2: 각 수요지점 i의 접근성 지수 계산
```
A_i^{2SFCA} = Σ_{j: d_ij ≤ d₀} R_j
```
- 해석: 값이 클수록 접근성 좋음 (더 많은 시설, 더 낮은 경쟁)
- 설계 원리: 더 많은 공급자가 도달 범위 내 있고 그 공급자들이 더 낮은 경쟁(높은 R_j)에 직면할수록 i의 접근성 증가

**E2SFCA (Enhanced 2SFCA)** (Luo & Qi, 2009)

Step 1 (Enhanced):
```
R_j = S_j / Σ_{k: d_kj ≤ d₀} P_k · W_kj
```

Step 2 (Enhanced):
```
A_i^{E2SFCA} = Σ_{j: d_ij ≤ d₀} R_j · W_ij
```
- W_ij: 거리 감쇠 가중치 — catchment 내 더 먼 출발지-목적지 쌍의 기여를 하향 조정
- 2SFCA의 이진 가정(catchment 내 동일 접근성)을 완화하여 더 현실적인 이용 행태 반영

**구현 시 필요 데이터**:
- 수요량 P_k가 있는 수요 위치 k
- 공급 용량 S_j가 있는 공급 위치 j
- 임피던스 d_ij (또는 OD 비용 행렬)
- (E2SFCA) 가중치 체계 W_ij 및 파라미터

**장점**: 공급-수요 균형 명시적 표현, 형평성 진단에 적합, E2SFCA는 catchment 내 거리 차등화로 더 현실적
**한계**: Catchment 및 가중치 선택에 의존, 수요·공급 데이터의 충분한 공간 해상도 필요, 복잡한 행동 반응이나 시스템 전체 피드백은 포착 못함

---

## 4. 서비스-지표 정렬 가이드

Ahn et al. (2026)의 프레임워크 핵심은 서비스 목적과 지표 구조의 **개념적 정렬**이다. Figure 1(b)는 대표적인 접근성 지표들을 조작화하는 요소에 따라 위치시킨다: 근접성 지표는 임피던스 꼭짓점 근처에, 기회 기반 지표는 임피던스-기회 트레이드오프 선상에, FCA형 지표는 경쟁이 명시적으로 표현되는 영역에 위치한다.

| 서비스 유형 | 지배 요소 | 적합 지표 | 부적합 지표 및 이유 |
|-------------|-----------|-----------|---------------------|
| Time-critical | Impedance | MIN, 반응시간 커버리지 | 2SFCA — 불필요한 파라미터, 신속 도달이 핵심인 맥락에서 정책 인사이트 불명확 |
| Opportunity-driven | Opportunity | COM, Gravity | MIN만 사용 — 선택지 다양성 미포착 |
| *(모든 유형, 빠른 기준선)* | — | **PPR** | 단독 사용 시 공간 상호작용·경쟁 미반영 → 기준선 또는 다른 지표와 비교 용도로 활용 |
| Capacity-constrained | Competition | 2SFCA, E2SFCA | Proximity만 — 수요 압력 무시, 실질 접근성 과대평가, 공간적 불형평 은폐 |

> PPR의 simplex 위치 (Ahn et al., 2026, Figure 1b): 기회(Opportunity)–경쟁(Competition) 경계에 위치. 인구 정규화로 수요 압력을 반영하지만, 이동 임피던스나 catchment 기반 공간 상호작용은 표현하지 않음.

**오적용의 위험** (Ahn et al., 2026):
- 응급 맥락에 경쟁 조정 지표를 적용하면, 신속한 도달이 지배적 목적인 상황에서 추가 가정과 파라미터만 도입하여 정책 해석을 오히려 흐린다
- 용량 제약 서비스에 근접성 지표만 사용하면, 국지적 수요 압력을 무시하여 접근성을 과대평가하고 제한된 자원에 대한 경쟁으로 인한 부족과 공간적 불형평을 은폐한다

> **정신건강의학과 분류**: Capacity-constrained (Type III) → **2SFCA 또는 E2SFCA 권장**
>
> 이유: 정신건강의학과 전문의 수와 진료 가능 시간은 제한되어 있으며, 특정 지역(대도시)에 수요가 집중되면 실질 접근성이 크게 저하된다. 단순 근접성 지표만 사용하면 대도시 주변부나 농촌 지역의 의료 공백을 과소평가할 위험이 있다. 2SFCA는 공급-수요 비율(R_j)을 통해 이 경쟁 효과를 명시적으로 포착한다.

---

## 5. Catchment 반경(threshold_km) 설정 근거

Catchment 반경은 분석 결과에 직접적인 영향을 미치는 핵심 파라미터다. Ahn et al. (2026)은 이 선택이 많은 적용 사례에서 보편적으로 인정된 이론보다는 **선례나 데이터 관행**에 의해 결정되며, 따라서 민감도 분석과 파라미터 설정의 투명한 보고가 신뢰할 수 있는 정책 해석에 필수적임을 강조한다.

| 지역 유형 | 권장 반경 | 근거 |
|-----------|-----------|------|
| 대도시 (서울, 부산 등) | 5~10 km | 대중교통 접근성 높음, 이동 시간 단축 |
| 중소도시 (대전, 광주 등) | 10~15 km | 승용차 약 20분 이내 |
| 농촌·군 지역 | 20~30 km | 승용차 약 30~40분 이내 |
| 광역 분석 (도 단위, 농촌 포함) | 20~30 km | 충청권 등 농촌 비율 높은 지역 적합 |
| 도서·산간 | 30~50 km | 지형적 고립 및 네트워크 우회 고려 |

> ⚠️ **주의사항**:
> - 반경이 클수록 더 많은 시설이 catchment에 포함되어 접근성 지수가 전반적으로 높아짐
> - 지역 간 비교 분석 시 **동일 반경 사용 필수**
> - threshold-based 지표(COM, 2SFCA)는 경계면 절벽 효과(cliff-edge effect) 존재 — 반경 바로 바깥 시설은 접근성 기여 0으로 처리됨
> - 이 한계를 보완하려면 E2SFCA에 연속 감쇠 함수(gaussian, exponential) 적용 고려

---

## 6. 거리 감쇠 함수 선택 가이드 (E2SFCA용)

E2SFCA에서 W_ij(거리 감쇠 가중치)의 함수 형태 선택은 "catchment 내 이용자가 거리에 따라 얼마나 다르게 이용하는가"라는 행동 가정을 반영한다. 선택된 감쇠 명세 및 파라미터에 따라 결과가 달라질 수 있으므로 (Ahn et al., 2026), 선택 근거를 명시하는 것이 중요하다.

| 함수 | 형태 | 권장 상황 | 파라미터 |
|------|------|-----------|----------|
| **gaussian** | 종 모양 연속 감쇠 | 대부분의 의료 서비스 **(기본 추천)** | beta = sigma (표준편차, 단위 m) |
| **exponential** | 초기 급격 감쇠 후 완만 | 응급성 높거나 단거리 집중 이용 | beta (감쇠율, 1/km) |
| **power** | 완만하고 긴 꼬리 | 광역 이용 패턴, 원거리도 일부 이용 | beta (지수) |
| **step** | 구간별 계단형 | 정책 기준 구간이 명확할 때 (예: 10·20·30km 구간 차등) | distance_bands_json |
| **binary** | 반경 내 동일 가중치 | 2SFCA와 동일 결과 (검증·비교용) | — |

**gaussian 파라미터(sigma) 설정 예시**:
- 도심 단거리 서비스: sigma = 5,000m (5km)
- 중거리 의료 서비스: sigma = 10,000m (10km)
- 광역 농촌 서비스: sigma = 20,000m (20km)

---

## 7. 방법론적 주의사항

Ahn et al. (2026)은 개념적으로 적합한 지표 패밀리를 선택하더라도 공간 접근성 분석에는 신중한 해석이 필요한 방법론적 불확실성이 수반됨을 강조한다.

### 7.1 공간 집계 문제 (MAUP)
공간 단위(행정구역 vs. 격자) 및 집계 규모 선택에 따라 접근성 추정값과 공간 패턴이 달라질 수 있다 (Wong, 2004). 더 거친 집계 단위는 미시적 격차를 평균화하여 국지적 서비스 공백이나 취약 인구를 숨길 수 있다. 이 한계는 더 복잡한 지표를 채택한다고 해결되지 않는 구조적 문제다.

**대응**: 입력 데이터의 공간 해상도를 명시적으로 보고하고, 가능하면 다중 스케일 민감도 분석 수행

### 7.2 파라미터 선택 민감도
Catchment 반경(d₀), 감쇠 함수 형태, 감쇠 파라미터(β) 선택이 결과에 실질적 영향을 미친다. 많은 적용 사례에서 이 선택이 보편적으로 인정된 이론보다는 선례나 데이터 관행에 의존하며, 이는 재현성과 비교가능성을 제한한다.

**대응**: 민감도 분석 수행 및 파라미터 설정의 투명한 보고 필수

### 7.3 정책 해석 시 유의점
- 접근성 지표는 공간적 관계에서의 서비스 도달 잠재력을 측정하는 것이며, 실제 이용률이나 비공간적 접근 장벽(사회경제적 요인, 제도적 요인 등)은 범위 외
- FCA 지표는 복잡한 행동 반응이나 시스템 전체 피드백은 포착하지 못하는 양식화된 근사치
- "낮은 접근성"의 의미는 선택된 지표 패밀리에 따라 달라지므로, 지표 선택 근거를 항상 명시

---

## 참고문헌

- **Ahn, J., Kim, H., & Lee, T. (2026).** A Conceptual Framework for Spatial Accessibility: Aligning Metrics with Urban Service Determinants. *KAIST ISysE Preprint.* *(본 문서의 주요 이론적 기반)*
- Apparicio, P., Abdelmajid, M., Riva, M., & Shearmur, R. (2008). Comparing alternative approaches to measuring the geographical accessibility of urban health services. *International Journal of Health Geographics*, 7, 7.
- Geurs, K. T., & van Wee, B. (2004). Accessibility evaluation of land-use and transport strategies. *Journal of Transport Geography*, 12(2), 127–140.
- Guagliardo, M. F. (2004). Spatial accessibility of primary care: concepts, methods and challenges. *International Journal of Health Geographics*, 3(1), 3.
- Hansen, W. G. (1959). How accessibility shapes land use. *Journal of the American Institute of Planners*, 25(2), 73–76.
- Luo, W., & Wang, F. (2003). Measures of spatial accessibility to healthcare in a GIS environment. *Environment and Planning B*, 30(6), 865–884.
- Luo, W., & Qi, Y. (2009). An enhanced two-step floating catchment area (E2SFCA) method. *Health & Place*, 15(4), 1100–1107.
- Neutens, T. (2015). Accessibility, equity and health care. *Journal of Transport Geography*, 43, 14–27.
- Páez, A., Scott, D. M., & Morency, C. (2012). Measuring accessibility: positive and normative implementations. *Journal of Transport Geography*, 25, 141–153.
- Wachs, M., & Kumagai, T. G. (1973). Physical accessibility as a social indicator. *Socio-Economic Planning Sciences*, 7(5), 437–456.
- Wong, D. W. (2004). The modifiable areal unit problem (MAUP). Springer.
